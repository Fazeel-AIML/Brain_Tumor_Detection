import os
import cv2
import numpy as np
import glob
import matplotlib.pyplot as plt

def calculate_tumor_size(contour, pixel_to_cm):
    # Calculate the area of the contour
    area = cv2.contourArea(contour)

    # Convert the tumor size from pixels to centimeters
    tumor_size_cm = area * pixel_to_cm

    return tumor_size_cm

def detect_tumor_size(image_path, pixel_to_cm, max_size_cm):
    try:
        # Load the image
        image = cv2.imread(image_path)

        if image is None:
            raise Exception("Failed to load the image")

        # Convert the image to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        # Apply Gaussian blur to reduce noise
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)

        # Apply Canny edge detection to identify edges
        edges = cv2.Canny(blurred, 30, 150)

        # Find contours of the tumor
        contours, _ = cv2.findContours(edges.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Iterate over contours and calculate the size of the tumor
        tumor_size = 0
        tumor_contour = None
        for contour in contours:
            # Calculate the area of each contour
            area = cv2.contourArea(contour)

            # Exclude small contours and select the largest contour
            if area > tumor_size:
                tumor_size = area
                tumor_contour = contour

        # Convert tumor size from pixels to centimeters
        tumor_size_cm = calculate_tumor_size(tumor_contour, pixel_to_cm)

        # Check if tumor size exceeds the maximum allowed size
        if tumor_size_cm > max_size_cm:
            raise Exception("Tumor size exceeds the maximum allowed size")

        # Return the total tumor size in centimeters and the selected contour
        return tumor_size_cm, tumor_contour

    except Exception as e:
        print("Error:", str(e))
        return None, None

# Path to the folder containing the images
image_folder = "yes"

# Get the list of image files in the folder
image_files = glob.glob(os.path.join(image_folder, "*.jpg"))

# Define the conversion factor (pixels to centimeters)
pixel_to_cm = 0.0001  # Example conversion factor, replace with your own

# Define the maximum allowed tumor size in centimeters
max_size_cm = 15  # Example maximum size, replace with your own

# Loop over each image file
for img_path in image_files:
    # Load and preprocess the image
    image = cv2.imread(img_path)
    print("Processing image:", img_path)

    # Resize the image
    dim = (500, 590)
    image = cv2.resize(image, dim)

    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply thresholding
    (T, thresh) = cv2.threshold(gray, 142, 155, cv2.THRESH_BINARY)
    (T, threshInv) = cv2.threshold(gray, 155, 155, cv2.THRESH_BINARY_INV)

    # Morphological operations
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))
    closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    closed = cv2.erode(closed, None, iterations=19)
    closed = cv2.dilate(closed, None, iterations=19)

    # Masking
    ret, mask = cv2.threshold(closed, 142, 255, cv2.THRESH_BINARY)
    final = cv2.bitwise_and(image, image, mask=mask)

    # Canny edge detection
    def auto_canny(image, sigma=0.90):
        v = np.median(image)
        lower = int(max(0, (1.0 - sigma) * v))
        upper = int(min(255, (1.0 + sigma) * v))
        edged = cv2.Canny(image, lower, upper)
        return edged

    canny = auto_canny(closed)

    # Contour detection and drawing
    (cnts, _) = cv2.findContours(canny.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Initialize the tumor contour
    tumor_contour = None

    # Find the largest contour
    if len(cnts) > 0:
        tumor_contour = max(cnts, key=cv2.contourArea)

    if tumor_contour is not None:
        # Calculate the tumor size based on the contour
        size = calculate_tumor_size(tumor_contour, pixel_to_cm)

        # Check if tumor size exceeds the maximum allowed size
        if size > max_size_cm:
            print("Tumor size exceeds the maximum allowed size")
        else:
            # Draw the tumor contour on the image
            cv2.drawContours(image, [tumor_contour], -1, (0, 0, 255), 10)

            # Display the image with the tumor size label
            plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
            plt.title("Tumor size: {:.2f} cm".format(size))
            plt.axis('off')
            plt.show()

            # Close the plot window to proceed to the next image
            plt.close()
    else:
        print("No tumor contour found in the image.")